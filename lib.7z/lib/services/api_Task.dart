import 'dart:convert';
import 'package:rest_client/rest_client.dart' as rc;
import 'package:http/http.dart' as http;
import 'package:json_annotation/json_annotation.dart';
import 'package:path/path.dart';
import 'dart:async';

//My packages
import 'package:snns_cm/config/application.dart';
import 'package:snns_cm/models/User.dart';
import 'package:snns_cm/models/Node.dart';
import 'package:snns_cm/models/Task.dart';
import 'package:snns_cm/models/MonitorData.dart';

// getTasks() - 从服务端获取 [任务] 数据
Future<List<Task>> getTasks() async {
  var responseTask =
      await http.get(Application.servUrl + '/v1/task/selecttask');
  var dataTask = json.decode(responseTask.body);
  List<dynamic> taskJson = dataTask['data'];
  List<Task> tasks = [];
  taskJson.forEach(
    (json) => tasks.add(
      Task.fromJson(json),
    ),
  );
  return tasks;
}

// saveTasks() - 向服务端保存 [任务] 数据
Future<http.Response> saveTasks(
    String taskid, String name, String describe) async {
  var post = {
    "taskid": "${taskid}",
    "name": "${name}",
    "describe": "${describe}"
  };
  var taskbody = utf8.encode(json.encode(post));
  var responseTask = await http.post(
      Application.servUrl + '/v1/task/inserttask',
      headers: {"content-type": "application/json"},
      body: taskbody);
  print("${responseTask.statusCode}");
  print("${responseTask.body}");
  // var dataTask = json.decode(responseTask.body);
  // List<dynamic> taskJson = dataTask['data'];
  // List<Task> tasks = [];
  // taskJson.forEach(
  //   (json) => tasks.add(
  //     Task.fromJson(json),
  //   ),
  // );
  return responseTask;
}
