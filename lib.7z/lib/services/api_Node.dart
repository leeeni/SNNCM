import 'dart:convert';
import 'package:rest_client/rest_client.dart' as rc;
import 'package:http/http.dart' as http;
import 'package:json_annotation/json_annotation.dart';
import 'package:path/path.dart';
import 'dart:async';

//My packages
import 'package:snns_cm/config/application.dart';
import 'package:snns_cm/models/User.dart';
import 'package:snns_cm/models/Node.dart';
import 'package:snns_cm/models/Task.dart';
import 'package:snns_cm/models/MonitorData.dart';

//String url = "http://127.0.0.1:80/api";
//final Box userBox = Hive.box('userBox');
//var token = userBox.get('token');

// var url = 'http://127.0.0.1:80/api/v1/node/insertnode';
// var node =
//     new Node(name: 'test3', ip: '202.116.130.1', describe: 'SNN03 test3');
// print(jsonEncode(node).toString());
// var response = await http.post(url, body: jsonEncode(node).toString());
// print(response.body.toString());

// getNodes() - 从服务端获取 [节点] 数据
Future<List<Node>> getNodes() async {
  var responseNode =
      await http.get(Application.servUrl + '/v1/node/selectnode');
//  print(response.body.toString());
  var dataNode = json.decode(responseNode.body);
//  print(data);
  List<dynamic> tnodeJson = dataNode['data'];
  // print(tnodeJson);
  List<Node> nodes = [];
  tnodeJson.forEach(
    (json) => nodes.add(
      Node.fromJson(json),
    ),
  );
  // print(nodes.length);
  // print(nodes);
  return nodes;
}
