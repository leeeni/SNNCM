import 'dart:convert';
import 'package:rest_client/rest_client.dart' as rc;
import 'package:http/http.dart' as http;
import 'package:json_annotation/json_annotation.dart';
import 'package:path/path.dart';
import 'dart:async';

//My packages
import 'package:snns_cm/config/application.dart';
import 'package:snns_cm/models/User.dart';

// getUsers() - 从服务端获取 [用户] 数据
Future<List<User>> getUsers() async {
  var responseUser =
      await http.get(Application.servUrl + '/v1/user/selectuser');
//  print(response.body.toString());
  var dataUser = json.decode(responseUser.body);
//  print(data);
  List<dynamic> userJson = dataUser['data'];
  // print(userJson);
  List<User> users = [];
  userJson.forEach(
    (json) => users.add(
      User.fromJson(json),
    ),
  );
  // print(users.length);
  // print(users);
  return users;
}

// signup() - 向服务端注册 [用户]
Future<http.Response> signup(String name, String password) async {
  var post = {
    "username": "${name}",
    "password": "${password}",
  };
  var taskbody = utf8.encode(json.encode(post));
  var responseSignup = await http.post(Application.servUrl + '/v1/user/signup',
      headers: {"content-type": "application/json"}, body: taskbody);
  print("${responseSignup.statusCode}");
  print("${responseSignup.body}");
  // var dataTask = json.decode(responseTask.body);
  // List<dynamic> taskJson = dataTask['data'];
  // List<Task> tasks = [];
  // taskJson.forEach(
  //   (json) => tasks.add(
  //     Task.fromJson(json),
  //   ),
  // );
  return responseSignup;
}

// login() - 向服务端注册 [用户]
Future<http.Response> login(String name, String password) async {
  var post = {
    "username": "${name}",
    "password": "${password}",
  };
  var taskbody = utf8.encode(json.encode(post));
  var responseSignup = await http.post(Application.servUrl + '/v1/user/login',
      headers: {"content-type": "application/json"}, body: taskbody);
  print("${responseSignup.statusCode}");
  print("${responseSignup.body}");
  // var dataTask = json.decode(responseTask.body);
  // List<dynamic> taskJson = dataTask['data'];
  // List<Task> tasks = [];
  // taskJson.forEach(
  //   (json) => tasks.add(
  //     Task.fromJson(json),
  //   ),
  // );
  return responseSignup;
}
