class User {
  String id;
  String username;
  String password;
  DateTime regdate;
  bool admin;
  bool actived;

  User({this.username, this.password, this.regdate, this.admin, this.actived});

  static User map(Map map) => new User()..fromMap(map);

  Map toJson() => {
        'id': id,
        'name': username,
        'password': password,
        'regdate': regdate,
        'admin': admin,
        'actived': actived,
      };

  User.fromJson(Map<String, dynamic> json) {
    id = json['UID'];
    username = json['Username'];
    password = json['Password'];
    //regdate = json['CreatedTime'];
    //admin = json['Role'];
    actived = json['IsBanned'];
  }

  void fromMap(Map map) => this
    ..id = map['id']
    ..username = map['username']
    ..password = map['password']
    ..regdate = map['regdate']
    ..admin = map['admin']
    ..actived = map['actived'];

  String toString() => toJson().toString();
}
