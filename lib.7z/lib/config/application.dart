import 'package:fluro/fluro.dart';

class Application {
  static FluroRouter router;
  static String servUrl;
  static String redisUrl;
  static String noteBookUrl;
  static String taskidNow;
  static String taskNameNow;
  static bool isLoginined;
  static String username;
  static int userstate;
  static bool usersys;
  static bool useradmin;
}
