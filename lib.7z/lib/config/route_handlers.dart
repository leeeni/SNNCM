import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';

import 'package:snns_cm/components/app/app_component.dart';
import 'package:snns_cm/components/home/home_component.dart';
import 'package:snns_cm/components/pages/MonitorCluster.dart';
import 'package:snns_cm/components/pages/MonitorPC.dart';
import 'package:snns_cm/components/pages/TaskList.dart';
import 'package:snns_cm/components/pages/TaskDetails.dart';
import 'package:snns_cm/components/pages/TaskReplay.dart';
import 'package:snns_cm/components/pages/NodeList.dart';
import 'package:snns_cm/components/pages/UserList.dart';

var rootHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return AppComponent();
});

var monitorClusterHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return MonitorCluster();
});

var monitorPcHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return MonitorPC();
});

var taskListHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return TaskList();
});

var taskDetailsHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return TaskDetails();
});

var taskReplayHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return TaskReplay();
});

var nodeListHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return NodeList();
});

var userListHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return UserList();
});

var setingHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return TaskList();
});

var helpHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return TaskList();
});

var aboutHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> params) {
  return TaskList();
});
