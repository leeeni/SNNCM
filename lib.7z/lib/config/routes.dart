import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import './route_handlers.dart';

class Routes {
  static String root = "/index";
  static String monitorCluster = "/monitorCluster";
  static String monitorPC = "/monitorPC";
  static String taskList = "/taskList";
  static String taskDetails = "/taskDetails";
  static String taskReplay = "/taskReplay";
  static String nodeList = "/nodeList";
  static String userList = "/userList";
  static String seting = "/seting";
  static String help = "/help";
  static String about = "/about";

  static String demoFunc = "/demo/func";
  static String deepLink = "/message";

  static void configureRoutes(FluroRouter router) {
    router.notFoundHandler = Handler(
        handlerFunc: (BuildContext context, Map<String, List<String>> params) {
      print("ROUTE WAS NOT FOUND !!!");
    });
    router.define(root, handler: rootHandler);
    router.define(monitorCluster, handler: monitorClusterHandler);
    router.define(monitorPC, handler: monitorPcHandler);
    router.define(taskList, handler: taskListHandler);
    router.define(taskDetails, handler: taskDetailsHandler);
    router.define(taskReplay, handler: taskReplayHandler);
    router.define(nodeList, handler: nodeListHandler);
    router.define(userList, handler: userListHandler);
    router.define(seting, handler: setingHandler);
    router.define(help, handler: helpHandler);
    router.define(about, handler: aboutHandler);
    //router.define(demoSimpleFixedTrans,
    //    handler: demoRouteHandler, transitionType: TransitionType.inFromLeft);
    //router.define(demoFunc, handler: demoFunctionHandler);
    //router.define(deepLink, handler: deepLinkHandler);
  }
}
